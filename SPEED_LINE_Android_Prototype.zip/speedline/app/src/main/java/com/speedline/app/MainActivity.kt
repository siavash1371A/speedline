package com.speedline.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var locationText: TextView
    private lateinit var scanButton: Button
    private var scanning = false
    private val requestCodeLocation = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 16, 30)
        window.navigationBarColor = Color.rgb(8, 16, 30)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(Color.rgb(8, 16, 30))
        }
        val brand = TextView(this).apply {
            text = "SPEED LINE"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        root.addView(brand, matchWrap())
        val subtitle = TextView(this).apply {
            text = "ارتباط هوشمند راننده‌ها"
            textSize = 15f
            setTextColor(Color.rgb(150, 171, 198))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 34)
        }
        root.addView(subtitle, matchWrap())

        val radar = TextView(this).apply {
            text = "◉"
            textSize = 94f
            setTextColor(Color.rgb(0, 214, 170))
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 12)
        }
        root.addView(radar, matchWrap())

        val range = TextView(this).apply {
            text = "شعاع شناسایی هدف: ۳۰۰ متر"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(range, matchWrap())

        status = TextView(this).apply {
            text = "وضعیت: غیرفعال"
            textSize = 16f
            setTextColor(Color.rgb(255, 205, 90))
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 18)
            background = rounded(Color.rgb(22, 35, 54), 18)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        locationText = TextView(this).apply {
            text = "موقعیت مکانی هنوز دریافت نشده است."
            textSize = 13f
            setTextColor(Color.rgb(150, 171, 198))
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 22)
        }
        root.addView(locationText, matchWrap())

        scanButton = Button(this).apply {
            text = "شروع شناسایی"
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.rgb(8, 16, 30))
            background = rounded(Color.rgb(0, 214, 170), 18)
            setOnClickListener { onScanPressed() }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, 58))

        val note = TextView(this).apply {
            text = "نسخه آزمایشی ۰.۱\nبرای نمایش خودروهای دیگر، اتصال امن به سرور و نصب برنامه روی گوشی دوم لازم است. در این نسخه هنوز هیچ موقعیتی برای دیگران ارسال نمی‌شود."
            textSize = 12f
            setTextColor(Color.rgb(128, 147, 171))
            gravity = Gravity.CENTER
            setPadding(8, 30, 8, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun onScanPressed() {
        if (scanning) {
            scanning = false
            status.text = "وضعیت: غیرفعال"
            status.setTextColor(Color.rgb(255, 205, 90))
            scanButton.text = "شروع شناسایی"
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCodeLocation)
            return
        }
        startLocalDemo()
    }

    private fun startLocalDemo() {
        scanning = true
        status.text = "وضعیت: فعال – آماده‌سازی موقعیت"
        status.setTextColor(Color.rgb(0, 214, 170))
        scanButton.text = "توقف شناسایی"
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            var loc: Location? = null
            for (provider in providers) {
                if (lm.isProviderEnabled(provider)) {
                    val candidate = lm.getLastKnownLocation(provider)
                    if (candidate != null && (loc == null || candidate.time > loc!!.time)) loc = candidate
                }
            }
            locationText.text = if (loc != null) {
                "موقعیت فعلی دریافت شد ✓\nدقت تقریبی: ${loc!!.accuracy.toInt()} متر\n(مختصات فقط روی همین گوشی نمایش داده می‌شود)"
            } else {
                "دسترسی مکان فعال شد؛ برای دریافت موقعیت، GPS گوشی را روشن کن."
            }
            status.text = "وضعیت: فعال – نسخه آزمایشی"
        } catch (_: SecurityException) {
            locationText.text = "اجازه دسترسی به موقعیت داده نشد."
        } catch (_: Exception) {
            locationText.text = "موقعیت فعلاً در دسترس نیست. GPS را بررسی کن."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCodeLocation) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) startLocalDemo()
            else locationText.text = "برای آزمایش موقعیت، اجازه مکان لازم است."
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }
}
